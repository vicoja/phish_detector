import pandas as pd
import random

# ============================================
# 1. Create LIST of sample legitimate URLs
# ============================================

legit_urls = [
    "https://www.google.com",
    "https://www.twitter.com",
    "https://www.microsoft.com",
    "https://www.wikipedia.org",
    "https://www.facebook.com",
    "https://www.amazon.com",
    "https://www.youtube.com",
    "https://www.linkedin.com",
    "https://www.github.com",
    "https://www.stackoverflow.com",
    "https://www.apple.com",
    "https://www.nytimes.com",
    "https://www.bbc.com",
    "https://www.whatsapp.com",
    "https://www.paypal.com",
]

# ============================================
# 2. Create LIST of sample phishing URLs
# ============================================

phish_urls = [
    "http://login-verify-paypal.com",
    "http://secure-update-banklogin.net",
    "http://account-confirm-facebook-alert.com",
    "http://reset-password-amazon-support.net",
    "http://microsoft-secure-update-info.ru",
    "http://google-login-alert-security.xyz",
    "http://verify-paypal-alert-center.info",
    "http://bankofamerica-update-login-security.cn",
    "http://appleid-verify-now-security.in",
    "http://facebook-support-secure-login.cc",
    "http://instagram-verification-alert-help.info",
    "http://verify-login-delivery-ups.com",
    "http://dhl-secure-update-info.net",
    "http://gmail-verification-login-alert.co",
    "http://update-security-amazon-support.org",
]

# ============================================
# 3. Add 200 RANDOM malicious-style URLs
# ============================================

words = ["secure", "verify", "bank", "alert", "confirm", "account", "update", "login", "unlock"]
domains = ["info", "xyz", "ru", "cn", "click", "shop", "top", "link"]

for _ in range(200):
    w1 = random.choice(words)
    w2 = random.choice(words)
    d = random.choice(domains)
    num = random.randint(10, 99999)

    phish_urls.append(
        f"http://{w1}-{w2}-{num}.{d}"
    )

# ============================================
# 4. Build a DataFrame
# ============================================

data = {
    "url": legit_urls + phish_urls,
    "label": [0] * len(legit_urls) + [1] * len(phish_urls)
}

df = pd.DataFrame(data)

# ============================================
# 5. Save dataset
# ============================================

df.to_csv("data/combined_urls.csv", index=False)

print("✅ Dataset created successfully!")
print("✅ Saved as data/combined_urls.csv")
print("✅ Total rows:", len(df))
print("✅ Legitimate URLs:", len(legit_urls))
print("✅ Phishing URLs:", len(phish_urls))
